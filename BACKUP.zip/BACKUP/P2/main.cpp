#include "tools.hpp"
#include "Params.hpp"
//#include "FileID.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

using namespace std;

int main(int argc, char* argv[]) {
  banner();
  
  Params par(argc, argv);
  //Sniff sn(par);
  
  //chdir(sn.firstDir);
  //sn.oneFile(sn.firstDir);
  
  bye();
  return 0;
}
