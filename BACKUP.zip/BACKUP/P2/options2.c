/******************************************************************************
 *	Demonstrate use of getopt() for long options.		    File: options2.c
 *	Alice Fischer							                 January 9, 2010
 ******************************************************************************/
#include <stdio.h>
#include <getopt.h>
void usage();

int main(int argc, char* argv[])
{
	// Define all the long switches. -------------------------------------------
	struct option longOpts[] = {
		{ "verbose",	no_argument,       NULL,  'b' },
		{ "output",		required_argument, NULL,  'o' },
		{ "recursive",  no_argument,       NULL,  'R' },
		{ "debug",		optional_argument, NULL,   0  },
		{ NULL,         0,                 NULL,   0  }
	};
	// -------------------------------------------------------------------------
	int code, ch, optx;
    printf("Command: %s\n", argv[0]);
	for (;;) {						// Process the command-line switches	
		ch = getopt_long(argc, argv, "i:abRo:u", longOpts, &code);
		if( ch == -1 ) break;		// No more recognized short switches.
		switch (ch) {
			case 'a':   // These switches do not have arguments.
			case 'u':	
			case 'b':
			case 'R':	printf("\n\tSwitch:    %c  ", ch );
                        break;
				
			case 'o':   // These switches require arguments.
			case 'i':   printf("\n\tSwitch:    %c  argument: %s ", ch, optarg);
                        break;

			case 0:	{		// Convert code for long switch to full name.
                printf("\n\tSwitch:    %s  ", longOpts[code].name );
                if( optarg != NULL ) printf(" \targument: %s", optarg);
				break;
			}
				
			case '?':		// Check for invalid switches.
            default:	usage();
		}     
	}
	
	// Now handle the rest of the arguments. -----------------------------------
	// for( optx = 0; optx < argc; ++optx ){       // For instruction, try this.
	for( optx = optind; optx < argc; ++optx ){
		printf("\n\tArgument:  %s \n", argv[optx] );
	}
	printf( " -------------------------------------------\n\n" ); 
	return 0;
}

//------------------------------------------------------------------------------
void usage(){
	printf("\nUsage:  options [-avRou] [--recursive] [--verbose] [--debug[=level]] \n"
		   "\t\t[-i filename] [--output filename] \n");
}

/* -------------------
 bash-3.2$ gcc -o options -Wall main.c

 bash-3.2$ ./options foo -avi fileame --recursive nonswitch anotherarg --output myout.txt --debug=2
 Switch:    a  
 Switch:    v  
 Switch:    i   	argument: fileame  
 Switch:    recursive  
 Switch:    o   	argument: myout.txt  
 Switch:    debug   	argument: 2  
 Argument:    foo 
 Argument:    nonswitch 
 Argument:    anotherarg 
 ------------------------------------------ // omits = with a required argument.

~> options foo -ai --recursive nonswitch anotherarg --output=myout.txt
Switch:    a  
Switch:    i   	argument: --recursive  
Switch:    o   	argument: myout.txt  
Argument:    foo 
Argument:    nonswitch 

------------------------------------------- // uses = with a required argument.
~> options foo -ai --recursive nonswitch anotherarg --verbose --output=myout.txt
Switch:    a  
Switch:    i   	argument: --recursive  
Switch:    b  
Switch:    o   	argument: myout.txt  
Argument:    foo 
Argument:    nonswitch 
Argument:    anotherarg 

------------------------------------------------------------------ // Error:
 [alice] jodi:~/<2>1-sysprog/code/W2~> options foo -ai --recursive nonswitch anotherarg --verbose --debug --output=myout.txt
Switch:    a  
Switch:    i   	argument: --recursive  
Switch:    b  
Switch:    debug  
Switch:    o   	argument: myout.txt  
Argument:    foo 
Argument:    nonswitch 
Argument:    anotherarg 

--------------------------------------------- omits = with an optional argument.
~> options foo -avi fileame -t --recursive nonswitch anotherarg --output=myout.txt
Switch:    a  
Usage:  options [-avRou] [--recursive] [--verbose] [--debug[=level]] 
		[-i filename] [--output filename] 
Switch:    i   	argument: fileame  
options: invalid option -- t
Usage:  options [-avRou] [--recursive] [--verbose] [--debug[=level]] 
		[-i filename] [--output filename] 
Switch:    R  
Switch:    o   	argument: myout.txt  
Argument:    foo 
Argument:    nonswitch 
Argument:    anotherarg 
 
 -----------------------------------------------  
 // -t switch is not supported.
 
 bash-3.2$ ./options foo -avi --recursive nonswitch anotherarg --output=myout.txt
 Switch:    a  
 Switch:    v  
 Switch:    i   	argument: --recursive  
 Switch:    o   	argument: myout.txt  
 Argument:    foo 
 Argument:    nonswitch 
 Argument:    anotherarg 
 ------------------------------------- // Error: -i switch requires an argument.
*/
