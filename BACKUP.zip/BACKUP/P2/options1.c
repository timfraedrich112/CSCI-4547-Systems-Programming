/******************************************************************************
 *	Demonstrate use of getopt() for short options.			File: options.c
 *	Alice Fischer									January 9, 2010
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
void usage();

int main(int argc, char* argv[])
{
    int code, ch, optx;
    for (;;) {					// Process the command-line switches
        ch = getopt(argc, argv, "i:abRo:u");
        if( ch == -1 ) break;	// No more recognized short switches.
        switch (ch) {
            case 'a':	// These switches do not have arguments.
            case 'u':
            case 'b':
            case 'R': printf("\n\tSwitch:    %c  ", ch );
                      if(optarg != NULL) printf(" \targument: %s ", optarg);
                      break;

            case 'o':	// These switches require arguments.
            case 'i':	printf("\n\tSwitch:    %c  ", ch );
                        if(optarg != NULL) printf(" \targument: %s ", optarg);
                        break;
            case '?':	// Check for invalid switches.
            default:	usage();
        }
    }

    // Now handle the rest of the arguments. -----------------------------------
    // for( optx = 0; optx < argc; ++optx ){       // For instruction, try this.
    for( optx = optind; optx < argc; ++optx ){
        printf("\n\tArgument:  %s ", argv[optx] );
    }
    printf( "\n -------------------------------------------\n\n" );
    return 0;
}

//------------------------------------------------------------------------------
void usage(){
    printf("Usage:  options [-abRou] [-i filename] \n");
    exit(1);
}

/optionsDemo~> opt2_23 --debug --verbose -aR -i myin.txt myout.txt
Command: opt2_23

    Switch:    debug
    Switch:    b
    Switch:    a
    Switch:    R
    Switch:    i  argument: myin.txt
    Argument:  myout.txt
-------------------------------------------
 ------------------------------------------- */
