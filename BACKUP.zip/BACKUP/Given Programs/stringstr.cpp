//-----------------------------------------------------------------------------
// Main program for the demo on deriving a class from a struct.
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

int main (int argc, char* const argv[]) {
	string word;
    cout << "\nDemo Program for StringStreams\n";

    cout <<"argv[1] = " <<argv[1] <<endl;
    string wlist(argv[1]);      // Convert from cstring to c++ string.
    istringstream instr(wlist); // Wrap a stream around the string.

    // Note: When parsing argv, the eof will occur when the last string is read, not the next time around the loop.
    for(;;) {
        instr >> word;
        cout <<word <<endl;
        if( instr.eof()) break;
     }
	return 0;
}

/*---------------------------------------------------------------------
 Demo Program for StringStreams
 argv[1] = many big errors
 many
 big
 errors
 ---------------------------------
 Teaching points in this example, by line number:
 3--5.  All three includes are needed.
 7.  I strongly prefer using this declaration and avoiding the need to write std:: in front of many things.
 13. While debugging a program, PLEASE echo your inputs.
 14. Many things in C++ need strings, not const char *s.   Check the documentation is you are unsure.  Using the string constructor is easy.
 15. The stringstream constructor wraps a stream around a C++ string.
 19. Use an istringstream the same way you would use cin.
 21. Test for eof() the same way you would test an ifstream.
 21. There was no newline in argv[1], so eof occurred when the last word was read.
 22. There is no need to close a stringstream.
 -------------------------------------------------------------------- */
