#include "tools.hpp"

using namespace std;

int main(int argc, char* argv[]) {
    ofstream outputFile("Project1_Fraedrich_Haller.txt", ios::out | ios::app);

    cout << "----------------" << endl;

    for (int i = 0; i < argc; i++) {
        if (i == 0) {
            cout << "command\t" << argv[i] << endl;
            outputFile << "command\t" << argv[i] << endl;
        } else if (argv[i][0] == '-') {
            cout << "switch\t" << argv[i] << endl;
            outputFile << "switch\t" << argv[i] << endl;
        } else {
            cout << "argument\t" << argv[i] << endl;
            outputFile << "argument\t" << argv[i] << endl;
        }
    }
    
    return 0;
}

/*
5.
e) Instead of printing the '>' operator, it was used as an indication, creating a file with the name mytemp.txt instead.

f) The * implies to use all of the following, so since there were already dummy files with the .bak ending, all of those were used. Whereas since there were no .log files, the line *.log was used
*/
