// ============================================================
// This  program demonstrates concurrent execution after a fork.
// ============================================================
#include "tools.h"

int main( void ) {
    int k;
    int parent = fork();         // Fork returns 0 or process id of new process.
    // ========================================================
    if (parent ) {              // Parent process receives non-zero pid of child.
        for(k=0; ; ++k) {
            say( "\n%d. This is the parent talking quietly.", k);
            say( "You should see my message and my daughter's "
                "message interleaved on the terminal screen; we "
                "are running concurrently.", k);
        }
        wait(NULL);               // When child terminates, parent gets signal.
        say("Parent Done.  Bye!\n");    // Type exit message when child is done.
        return 0;
    }
    
    // ========================================================
    else {                         // Child process receives a zero from fork().
        for(k=0; ; ++k) {
            say( "\n%d. THIS IS THE DAUGHTER SHOUTING.  KIDS ARE LOUD. ", k);
            say( " I AM EXECUTING CONCURRENTLY "
                "WITH MY PARENT.  YOU WILL SEE OUR MESSAGES INTERLEAVED ON "
                "YOUR TERMINAL SCREEN.");
        }
        say("DAUGHTER DONE.  BYE!\n");
        return 0;
    }
}
/* =============================================================================
Sample output from the middle of a run, after daghter had a chance to start.
 ...
 44. This is the parent talking quietly.
 You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.

 45. This is the parent talking quietly.
 You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.

 I AM EXECUTING CONCURRENTLY WITH MY PARENT.  YOU WILL SEE OUR MESSAGES INTERLEAVED ON YOUR TERMINAL SCREEN.
 46. This is the parent talking quietly.


 1. THIS IS THE DAUGHTER SHOUTING.  KIDS ARE LOUD. You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.

 I AM EXECUTING CONCURRENTLY WITH MY PARENT.  YOU WILL SEE OUR MESSAGES INTERLEAVED ON YOUR TERMINAL SCREEN.
 47. This is the parent talking quietly.


 2. THIS IS THE DAUGHTER SHOUTING.  KIDS ARE LOUD. You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.

 I AM EXECUTING CONCURRENTLY WITH MY PARENT.  YOU WILL SEE OUR MESSAGES INTERLEAVED ON YOUR TERMINAL SCREEN.
 48. This is the parent talking quietly.


 3. THIS IS THE DAUGHTER SHOUTING.  KIDS ARE LOUD. You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.

 I AM EXECUTING CONCURRENTLY WITH MY PARENT.  YOU WILL SEE OUR MESSAGES INTERLEAVED ON YOUR TERMINAL SCREEN.
 49. This is the parent talking quietly.


 4. THIS IS THE DAUGHTER SHOUTING.  KIDS ARE LOUD. You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.

 I AM EXECUTING CONCURRENTLY WITH MY PARENT.  YOU WILL SEE OUR MESSAGES INTERLEAVED ON YOUR TERMINAL SCREEN.
 50. This is the parent talking quietly.


 5. THIS IS THE DAUGHTER SHOUTING.  KIDS ARE LOUD. You should see my message and my daughter's message interleaved on the terminal screen; we are running concurrently.


...
*/
